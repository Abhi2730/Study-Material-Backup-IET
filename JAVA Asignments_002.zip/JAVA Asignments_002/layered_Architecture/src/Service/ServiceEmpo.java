package Service;

public interface ServiceEmpo {
	public Boolean addNewEmployee(int ch);
}

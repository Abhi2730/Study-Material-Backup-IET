package com.demo.beans;

import java.time.LocalDate;
import java.util.Objects;

public class Product implements Comparable<Product> {
	//data members
	private int pid;
	private String pname;
	private int qty;
	private float price;
	private LocalDate exdate;
	
	//Default Constructor
	public Product()
	{
		pid=0;
		pname=null;
		qty=0;
		price=0;
		exdate=null;
	}
	
	public Product(int pid)
	{
		this.pid=pid;
	}
	
	//Parameterized Constructor
	public Product(int pid,String pname,int qty,float price,LocalDate exdate)
	{
		this.pid=pid;
		this.pname=pname;
		this.qty=qty;
		this.price=price;
		this.exdate=exdate;
	}

	public int getPid() {
		return pid;
	}
	
	public String getPname() {
		return pname;
	}
	
	public int getQty() {
		return qty;
	}
	
	public float getPrice() {
		return price;
	}
	
	public LocalDate getExdate() {
		return exdate;
	}
	
	public void setPid(int pid) {
		this.pid = pid;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void setExdate(LocalDate exdate) {
		this.exdate = exdate;
	}
	
	public String toString()
	{
		return "Id= "+pid+" Name= "+pname+" Qty= "+qty+" Price= "+price+" Expiry Date= "+exdate;
	}

	@Override
	public int hashCode() {
		return pid;
	}

	@Override
	public boolean equals(Object obj) {
		Product other=((Product)obj);
		
		return this.pid==other.pid ;
	}

	@Override
	public int compareTo(Product o) {
		
		if(this.pid<o.pid)
			return -1;
		else if(this.pid==o.pid)
			return 0;
		else 
			return 1;
		
		//return this.pid-o.pid;
	}
	
	
	
}

package com.demo.queue;
import java.util.*;
public class TestQueue {

	public static void main(String[] args) {
		Queue<Integer> q = new PriorityQueue<>();
		q.add(23);
		q.add(12);
		q.add(10);
		q.add(27);
		
		System.out.println("Queue : "+q);
		
		//Priority Queue using Poll. Poll retrieves the element and delete it
		System.out.println("poll : "+q.poll());
		System.out.println("Queue : "+q);
		
		//peek retrieves the element but do not delete it
		System.out.println("Peek : "+q.peek());  //do not delete
		System.out.println("Poll : "+q.poll());  //delete
		System.out.println("Queue : "+q);
		System.out.println("Poll : "+q.poll());  //delete
		System.out.println("Peek : "+q.peek());  //do not delete
		

	}

}

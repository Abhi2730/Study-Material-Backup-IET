package com.demo.generics;
import com.demo.interface.

public class TestCheckGenerics {

	public static void main(String[] args) {
		
		CheckGenerics<Integer> c1 = new CheckGenerics<Integer>() {
			public Integer add(Integer x,Integer y);
		};

	}

}

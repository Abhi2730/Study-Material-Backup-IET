		import java.util.Scanner;

public class ArrayService {

	public static void addnewdata(int[][] arr2) {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr2.length;i++) {
			for(int j=0;j<arr2[i].length;j++) {
				System.out.println("enter number at row "+i+"Column"+j);
				arr2[i][j]=sc.nextInt();
			}
		}
	}

	public static void displaydata(int[][] arr2) {
		for(int i=0;i<arr2.length;i++) {
			for(int j=0;j<arr2[i].length;j++) {
				System.out.print(arr2[i][j]);
				
			}
		}
		
		
		
	}
	int sum=0;
	public static void mul(int[][] arr,int [][] arr1) {
		for(int i=0;i<arr2.length;i++) {
			for(int j=0;j<arr2[i].length;j++) {
				System.out.print(arr2[i][j]);
				sum=sum+(arr2[i][j]*arr1[j][i]);
				
			}
			for(k=0;k<3;k++)
			{
				arr[i][k]=sum;
			}
			
		}

}

package com.demo.dao;

import java.util.List;

import com.demo.beans.Product;

public interface ProductDao  {

	boolean save(Product p);

	List<Product> findAll();

	Product findById(int pid);

	List<Product> findByName(String name);

	List<Product> findByPrice(float price);

	List<Product> disSortByName();

	List<Product> arrangeByQty();

	List<Product> arrangeByPrice();

	boolean removeById(int id);

	boolean modifyProduct(int id, int quant, float price);
	

}

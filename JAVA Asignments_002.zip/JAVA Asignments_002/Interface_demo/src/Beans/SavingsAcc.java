package Beans;

import java.util.Date;


import Interfaces.CalculateBalance;

public class SavingsAcc extends Account implements CalculateBalance {
	
	private float minBalance;

	public SavingsAcc()
	{
		
	}
	
	
	public SavingsAcc(String accno, String name, Date doa, float minBalance) {
		super(accno,name,doa);
		this.minBalance = minBalance;
	}


	public float getMinBalance() {
		return minBalance;
	}


	public void setMinBalance(float minBalance) {
		this.minBalance = minBalance;
	}


	@Override
	public String toString() {
		
		
		
		return super.toString()+"SavingsAcc [minBalance=" + minBalance + "]";
	}


	@Override
	public void calbal() 
	{
		System.out.println("In Calbal method of Savings class");
		System.out.println("Minimum balance is: "+minBalance);
		
	}
	
	
	
}

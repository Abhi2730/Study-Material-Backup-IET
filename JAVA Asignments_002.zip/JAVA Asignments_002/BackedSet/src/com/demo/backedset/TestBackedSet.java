package com.demo.backedset;
import java.time.LocalDate;
import java.util.SortedSet;
import java.util.TreeSet;

public class TestBackedSet {

	public static void main(String[] args) {
		
		TreeSet<Product> tset = new TreeSet<>();
		
		tset.add(new Product(24,"Maggie",34,45,LocalDate.of(2024, 8, 11)));
		tset.add(new Product(5,"Marie",30,40,LocalDate.of(2024, 01, 11)));
		tset.add(new Product(17,"Bourbon",55,45,LocalDate.of(2024, 9, 9)));
		tset.add(new Product(12,"Kurkure",34,20,LocalDate.of(2024, 05, 06)));
		tset.add(new Product(31,"50-50",40,15,LocalDate.of(2024,07, 10)));
		
		tset.stream().forEach(System.out::println);
		
		SortedSet<Product> hset=tset.headSet(new Product(17));
		System.out.println("HeadSet for Id=17"+hset+"\n");
		
		SortedSet<Product> taset = tset.tailSet(new Product(17));
		System.out.println("TailSet for Id=17"+taset+"\n");
		
		tset.add(new Product(9,"Kitkat",40,15,LocalDate.of(2024,07, 10)));
		
		System.out.println("HeadSet for Id=17"+hset+"\n");
		System.out.println("TailSet for Id=17"+taset+"\n");
		
		//For element not present in set
		SortedSet<Product> hset1=tset.headSet(new Product(16));
		System.out.println("HeadSet for Id=16"+hset1+"\n");
		
		SortedSet<Product> taset1 = tset.tailSet(new Product(16));
		System.out.println("TailSet for Id=16"+taset1+"\n");
		
		tset.add(new Product(9,"Kitkat",40,15,LocalDate.of(2024,07, 10)));
		
		System.out.println("HeadSet for Id=16"+hset1+"\n");
		System.out.println("TailSet for Id=16"+taset1+"\n");
		
		
		System.out.println("Higher: "+tset.higher(new Product(17)));
		
		
	}

}

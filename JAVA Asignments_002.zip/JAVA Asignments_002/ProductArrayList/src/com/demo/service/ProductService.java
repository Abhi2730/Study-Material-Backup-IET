package com.demo.service;

import java.util.List;

import com.demo.beans.Product;

public interface ProductService {

	boolean addNewProduct();

	List<Product> displayAll();

	Product displayById(int pid);

	List<Product> displayByName(String name);

	List<Product> displayByPrice(float price);

	List<Product> sortByName();

	List<Product> sortByQty();

	List<Product> sortByPrice();

	boolean deleteById(int id);

	boolean modifyProduct(int id, int quant, float price);


}

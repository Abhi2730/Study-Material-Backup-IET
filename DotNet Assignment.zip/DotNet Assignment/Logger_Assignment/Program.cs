﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Soap;
using System.Text;
using System.Threading.Tasks;

namespace FILEIO_demo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath1 = @"C:\Users\IET\Desktop\DotNet Assignment\Logger_Assignment\Text1.txt";
            FileStream fs = null;
            if (File.Exists(filePath1))
            {
                fs = new FileStream(filePath1, FileMode.Append, FileAccess.Write);
            }
            else
            {
                fs = new FileStream(filePath1, FileMode.CreateNew, FileAccess.Write);
            }
            Customer customer = new Customer();
            Console.WriteLine("Enter ID :");
            customer.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name ");
            customer.CName = Console.ReadLine();
            Console.WriteLine("Enter address");
            customer.CAddress = Console.ReadLine();

            Logger logger = new Logger();


            string str = logger.dateTime;
            Console.WriteLine("Current Time is " + str);
            SoapFormatter sf = new SoapFormatter();
            sf.Serialize(fs, customer);//Converting object into data
            sf.Serialize(fs, logger);
            fs.Close();
            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }
  {
    [Serializable]
    public class Customer
    {
        private int _CId;
        private string _CName;
        private string _CAddress;



       //[NonSerialized]
        private string _Password = "123456";

        public string Password
        {
            get 
            {
                return _Password = "123456";
            }
            set
            {
                _Password = value;
            
            }
        }


        public string CAddress
        {
            get 
            {
                return _CAddress; 
            }
            set 
            {
                _CAddress = value;
            }
        }


        public string CName
        {
            get 
            {
                return _CName;
            
            }
            set 
            {
                _CName = value;
            
            }
        }


        public int Id
        {
            get { return _CId; }
            set { _CId = value; }
        }
        public string GetCustomerDetails()
        {
            string str = "CID " + _CId + "CName " + _CName + " CAddress " + _CAddress + " PAssword " + _Password;
            return str;
        }
    }
    [Serializable]
    public class Logger
    {
        private static Logger logger = new Logger();
        private string _dateTime;

        public string dateTime
        {
            get
            {
                _dateTime = DateTime.Now.ToString();
                return _dateTime;
            }
            set
            {
                _dateTime = value;
            }
        }

    }


}

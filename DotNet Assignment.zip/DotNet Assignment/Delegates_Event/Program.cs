﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Event
{
    internal class Program
    {
        public delegate void MyDelgate(int marks); //declaration
        static void Main(string[] args)
        {
            {
                Students student = new Students();
                Console.WriteLine("Welcome {0}", student.getName());
                Console.WriteLine("Enter your marks :");
                int mark = Convert.ToInt32(Console.ReadLine());

                MyDelgate obj1 = new MyDelgate(student.onSuccess);
                MyDelgate obj2 = new MyDelgate(student.onFailure);
                


                student.onPass += obj1; //coupling
                student.onFail += obj2;

                student.Marks = mark;
                Console.ReadLine();
            }
        }

        public class Students
        {
            public event MyDelgate onPass;
            public event MyDelgate onFail;

            private int _marks;

            public int Marks
            {
                set
                {
                    _marks = value;
                    if (_marks >= 35)
                    {
                        onPass(_marks);
                    }
                    else
                    {
                        onFail(_marks);
                    }
                }
                get
                {
                    return _marks;
                }
            }
            public void onSuccess(int mark)
            {
                Console.WriteLine("Congratulations you have passed with {0} marks :)", mark);
            }
            public void onFailure(int mark)
            {
                Console.WriteLine("you have failed with {0} marks :)", mark);
            }

            public string getName()
            {
                return "Abhishek";
            }
        }
    }

}
    


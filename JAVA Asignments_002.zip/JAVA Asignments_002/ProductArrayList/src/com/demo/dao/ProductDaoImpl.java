package com.demo.dao;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import com.demo.beans.Product;
import com.demo.comparator.*;
import com.demo.comparator.ByNameComparator;
public class ProductDaoImpl implements ProductDao{
	
	static List<Product> plist;
	static
	{
		plist=new ArrayList<>();
		plist.add(new Product(1,"maggie",40,90,LocalDate.of(2023, 05, 06)));
		plist.add(new Product(2,"kurkure",10,50,LocalDate.of(2024, 06, 10)));
		plist.add(new Product(3,"Wafers",20,30,LocalDate.of(2025, 06, 01)));
		
		
	}
	@Override
	public boolean save(Product p) {
		
		return plist.add(p);
	}
	@Override
	public List<Product> findAll() {
		
		return plist;
	}
	@Override
	public Product findById(int pid) {
		int pos=plist.indexOf(new Product(pid));
		if(pos!= -1)
		{
			return plist.get(pos);
		}
		else
		{
			return null;
		}
		
	}
	@Override
	public List<Product> findByName(String name) {
		List<Product> lst = plist.stream().filter(ob->ob.getPname().equals(name)).collect(Collectors.toList());
		if(lst.isEmpty())
		{
			return null;
		}
		return lst;
	}
	@Override
	public List<Product> findByPrice(float price) {
	
		List<Product> lst = plist.stream().filter(ob->ob.getPrice()>price).collect(Collectors.toList());
		if(lst.isEmpty())
		{
			return null;
		}
		return lst;
		
	}
	@Override
	public List<Product> disSortByName() {
		List<Product> lst = new ArrayList<>();
		
		for(Product prop:plist)
		{
			lst.add(prop);
		}
		
		lst.sort(new ByNameComparator());
		
		return lst;
	}
	@Override
	public List<Product> arrangeByQty() {
		List<Product> lst= new ArrayList<>();
		for(Product p:plist)
		{
			lst.add(p);
		}
		
		lst.sort(null);
		return lst;
	}
	@Override
	public List<Product> arrangeByPrice() {
		List<Product> lst= new ArrayList<>();
		for(Product pr : plist)
		{
			lst.add(pr);
		}
		lst.sort(new PriceComparator());
		return lst ;
	}
	@Override
	public boolean removeById(int id) {
		plist.remove(new Product(id));
		return true;
	}
	@Override
	public boolean modifyProduct(int id, int quant, float price) {
		
		Product p=findById(id);
		if(p!=null)
		{
			p.setQty(quant);
			p.setPrice(price);
			return true;
		}
		else 
		{
			return false;	
		}
		
		
	}
	
	

}

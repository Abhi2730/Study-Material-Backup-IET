package Test;

import java.util.Date;

public class TestAccount {

	public static void main(String[] args) {
		
		//SCurrentAcc obj1=new CurrentAcc(1234,"Akansha",new Date,)
		

	}

}
//String accno, String name, Date doa,int roi,float mbalance
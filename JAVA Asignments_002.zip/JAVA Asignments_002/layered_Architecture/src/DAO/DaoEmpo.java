package DAO;
import Beans.Employee;

public interface DaoEmpo {
	
	Boolean save(Employee emp);

	}



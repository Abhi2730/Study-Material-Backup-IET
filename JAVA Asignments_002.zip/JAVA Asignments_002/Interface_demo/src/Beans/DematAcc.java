package Beans;

public class DematAcc extends Account {
	
	private int accid;

	
	
	public DematAcc(int accid) {
		super();
		this.accid = accid;
	}
	
	public DematAcc() 
	{
		
		
	}
	
	
	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	@Override
	public String toString() {
		return super.toString()+"DematAcc [accid=" + accid + "]";
	}

	
}

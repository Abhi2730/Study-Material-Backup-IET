﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Netflix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" 1.Silver Member \n 2.Gold Member \n 3.Platinum Member");
            Console.WriteLine("Choice the Member Type");
            
            int id = Convert.ToInt32(Console.ReadLine());
            Factory obj = new Factory();
            member r = obj.GetFactory(id);
            r.Device();
            r.Quality();
            r.Download();
            Console.ReadLine();



        }
        public class Factory
        {
            public member GetFactory(int id)
            {
                if (id == 1)
                {
                    return new Silver();
                }
                if (id == 2)
                {
                    return new Gold();
                }
                if (id == 3)
                {
                    return new Platinum();
                }
                else
                {
                    return null;
                }
            }
        }
        public interface member
        {
            void Device();
            void Quality();
            void Download();
        }
        public class Silver : member
        {
            public void Device()
            {
                Console.WriteLine("Only one Device can login");
            }
            public void Quality()
            {
                Console.WriteLine("Quality is : 720p");
            }
            public void Download()
            {
                Console.WriteLine("Download Feature Disable");
            }
        }
        public class Gold : member
        {
            public void Device()
            {
                Console.WriteLine("Only Two Device can login");
            }
            public void Quality()
            {
                Console.WriteLine("Quality is : 1080p");
            }
            public void Download()
            {
                Console.WriteLine("Download Feature Disable");
            }
        }
        public class Platinum : member
        {
            public void Device()
            {
                Console.WriteLine("Only Four Device can login");
            }
            public void Quality()
            {
                Console.WriteLine("Quality is : 4k");
            }
            public void Download()
            {
                Console.WriteLine("Download Feature Enable");
            }
        }
    }
}

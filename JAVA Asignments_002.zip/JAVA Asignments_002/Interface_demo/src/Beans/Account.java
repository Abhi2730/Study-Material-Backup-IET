package Beans;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Account {
	private String accno;
	private String name;
	private Date doa;
	
	public Account()
	{
		this.accno = null;
		this.name = null;
		this.doa = null;
		
	}
	
	public Account(String accno, String name, Date doa) {
		//super();
		this.accno = accno;
		this.name = name;
		this.doa = doa;
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDoa() {
		return doa;
	}

	public void setDoa(Date doa) {
		this.doa = doa;
	}

	@Override
	public String toString() {
		
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy"); 
		String d=sdf.format(doa);
		
		return "Account [accno=" + accno + ", name=" + name + ", doa=" + d + "]";
	}
	
	
	

}

package Test;
import java.util.*;
import Service.ServiceEmpImpl;
public class TestEmpImpl {

	public static void main(String[] args) {
		
		
		int choice=0;
		Scanner scn=new Scanner(System.in);
		ServiceEmpImpl eservice = new ServiceEmpImpl();
		
		System.out.println("1.Add Employee Data \n2.Display All Employee Data");
		System.out.println("3.Search By Id \n4.Search By Name");
		System.out.println("5.Update Salary \n6.Exit");
		System.out.println("Enter your choice");
		choice=scn.nextInt();
		
		switch(choice)
		{
		case 1:
			System.out.println("1.Salarized Employee \n2.Contract Employee");
			int ch=scn.nextInt();
			boolean status=eservice.addNewEmployee(ch);
			if(status)
			{
				System.out.println("Data added Successfully");
			}
			else
			{
				System.out.println("Data adittion failed, array full");
			}
			break;
			
		case 2:
			break;
			
		case 3:
			break;
			
		case 4:
			break;
			
		case 5:
			break;
			
		case 6:
			break;
			
		default:
			break;
		}
		
		
		
	}

}

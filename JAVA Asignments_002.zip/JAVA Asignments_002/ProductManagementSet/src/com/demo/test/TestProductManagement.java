package com.demo.test;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.beans.Product;
import com.demo.service.*;

public class TestProductManagement {

	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		ProductService pservice=new ProductServiceImpl();
		int choice=0;
		do {
			System.out.println("1.Add Product \n2.Display All Product \n3.Display by Id");
			System.out.println("4.Display By Name \n5.Display By Price \n6.Sorted Order By Name");
			System.out.println("7.Sorted Order By Price \n8.Sorted Order By Id");
			System.out.println("9.Delete Product By Id\n10.Modify Product \n11.Exit");
			System.out.println("Enter Your Choice");
			choice=scn.nextInt();
			
			switch(choice)
			{
			case 1:
				boolean status=pservice.addNewProduct();
				if(status)
				{
					System.out.println("New Product Added Successfully");
				}
				else
				{
					System.out.println("Error Occurred");
				}
				break;
				
			case 2:
				Set<Product> set= pservice.displayAll();
				set.stream().forEach(ob->System.out.println(ob));
				break;
				
			case 3:
				System.out.println("Enter Id to Display");
				int id=scn.nextInt();
				
				Product p=pservice.displayById(id);
				if(p!=null)
				{
					System.out.println(p);
				}
				else
				{
					System.out.println("Id Not Found");
				}
				break;
				
			case 4:
				System.out.println("Enter Name to Display");
				String name=scn.next();
				
				List<Product> plist=pservice.displayByName(name);
				if(plist!=null)
				{
					plist.stream().forEach(ob->System.out.println(ob));
				}
				else
				{
					System.out.println("Not Found");
				}
				break;
				
			case 5:
				System.out.println("Enter Price to Display");
				float price=scn.nextFloat();
				plist=pservice.displayByPrice(price);
				if(plist!=null)
				{
					plist.stream().forEach(ob->System.out.println(ob));
				}
				else
				{
					System.out.println("Not Found");
				}
				break;
				
			case 6:
				plist=pservice.sortByName();
				plist.stream().forEach(System.out::println);
				break;
				
			case 7:
				plist=pservice.sortByPrice();
				plist.stream().forEach(System.out::println);
				break;
				
			case 8:
				set=pservice.sortById();
				set.stream().forEach(System.out::println);
				break;
				
			case 9:
				System.out.println("Enter Id to be deleted");
				int pid=scn.nextInt();
				
				status = pservice.deleteById(pid);
				if(status)
				{
					System.out.println("Deleted Successfullt");
				}
				else
				{
					System.out.println();
				}
				break;
				
			case 10:
				System.out.println("Enter Id to be modified");
				pid=scn.nextInt();
				System.out.println("Enter Modified Quantity");
				int qty=scn.nextInt();
				System.out.println("Enter Modified Price");
				float pr=scn.nextFloat();
				
				status=pservice.modifyProduct(pid,qty,pr);
				if(status)
				{
					System.out.println("Modified Successfully");
				}
				else
				{
					System.out.println("Modification Failed");
				}
				break;
				
			case 11:
				System.out.println("Thank You!!");
				scn.close();
				break;
				
			default:
				System.out.println("Wrong Choice");
				break;
			}
		}while(choice!=11);
		
		
	}

}

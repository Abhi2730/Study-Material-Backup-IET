﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PdfByEvents

{
    public delegate void MyDelegate();
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter which action to be performed: ");
            Console.WriteLine("1. Parse \n2.Validate \n3.Save");
            int i = Convert.ToInt32(Console.ReadLine());

            PDF MyPdf = new PDF();
            MyDelegate MyDel1 = new MyDelegate(MyPdf.onParse);
            MyDelegate MyDel2 = new MyDelegate(MyPdf.onValidate);
            MyDelegate MyDel3 = new MyDelegate(MyPdf.onSave);

            MyPdf.Call(i);

            MyPdf.Parse += MyDel1;
            MyPdf.Validate += MyDel2;
            MyPdf.Save += MyDel3;
            Console.ReadLine();
        }
    }
    public class PDF
    {
        public event MyDelegate Parse;
        public event MyDelegate Validate;
        public event MyDelegate Save;

        public void Call(int i)
        {
            switch (i)
            {
                case 1:
                    {
                        onParse();
                    }
                    break;
                case 2:
                    {
                        onValidate();
                    }
                    break;
                case 3:
                    {
                        onSave();
                    }
                    break;
                default:
                    Console.WriteLine("Enter a valid action");
                    break;
            }
        }
        public void onParse()
        {
            Console.WriteLine("Your PDF is parsed");
        }

        public void onValidate()
        {
            Console.WriteLine("Your PDF is validated");
        }

        public void onSave()
        {
            Console.WriteLine("Your PDF is saved");
        }
    }
}
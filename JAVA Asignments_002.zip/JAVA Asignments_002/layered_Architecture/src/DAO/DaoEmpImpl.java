package DAO;

import java.time.LocalDate;

import Beans.ContractEmp;
import Beans.Employee;
import Beans.SalariedEmp;

public class DaoEmpImpl implements DaoEmpo{

	static Employee [] earr;
	static int count;
	static
	{
		earr=new Employee[10];
		earr[0]=new SalariedEmp(1,"Akansha","33333","HR","Developer",LocalDate.of(2023,7,3), 45666);
		earr[1]=new SalariedEmp(2,"Abhi","566656","MNGR","Developer",LocalDate.of(2023,5,3),45666);
		earr[2]=new ContractEmp(3,"Joey","85456346","Sales","lead",LocalDate.of(2023,2,2),103,500);
		earr[3]=new ContractEmp(4,"Ram","6757476756","Management","JR",LocalDate.of(2083,12,6),103,600);
		count = 4;
	}
	
	
	
		@Override
	public Boolean save(Employee emp) {
		if(count< earr.length)
		{
			earr[count]=emp;
			count++;
			return true;
		}
		else
		{
			return false;
		}
		
	}
		
}

	//int pid, String pname, String mob,String dept, String desg,LocalDate ldt,double sal
	//LocalDate.of(2020, 02, 02)
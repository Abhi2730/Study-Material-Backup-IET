package com.demo.generics;

public interface CheckInterface<T>{
	
	T add(T x,T y);
	

}

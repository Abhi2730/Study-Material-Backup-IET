import java.util.Scanner;

class HelloWorld
{
	public static void main (String[] args)
	{
		System.out.println("Hello World \n");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Number: ")
		int num1 = sc.nextInt();
		System.out.println("Enter Second number: ")
		int num1 = sc.nextInt();
		int sum = num1+num2;
		System.out.println("Addition of digits is: ",sum);
	}
}
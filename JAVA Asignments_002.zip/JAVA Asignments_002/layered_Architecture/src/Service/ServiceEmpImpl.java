package Service;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import Beans.SalariedEmp;
import DAO.DaoEmpImpl;
import DAO.DaoEmpo;
import Beans.ContractEmp;
import Beans.Employee;

import java.time.LocalDate;

public class ServiceEmpImpl implements ServiceEmpo  {
	
	private DaoEmpo idao;
	
	public ServiceEmpImpl()
	{
		super();
		this.idao=new DaoEmpImpl();
	}

	public Boolean addNewEmployee(int ch) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Id");
		int id=sc.nextInt();
		
		System.out.println("Enter Name");
		String nm=sc.next();
		
		System.out.println("Enter Mobile Number");
		String mob=sc.next();
		
		System.out.println("Enter Employee Departmnet");
		String dept=sc.next();
		
		System.out.println("Enter Employee Designation");
		String desi=sc.next();
		
		System.out.println("Enter Date of Joining(dd/MM/yyyy)");
	    String dtoj=sc.next();
	    
	    LocalDate ldt=LocalDate.parse(dtoj, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	   
	    Employee emp=null;
		switch(ch)
		{
		case 1:
			System.out.println("Salarized Employee");
			System.out.println("Enter Salary");
			double salary=sc.nextDouble();
			emp=new SalariedEmp(id,nm,mob,dept,desi,ldt,salary);
			break;
			
		case 2:
			System.out.println("Contract Employee");
			System.out.println("Enter Salary");
			int hr=10;
			float charges=sc.nextFloat();
			emp=new ContractEmp(id,nm,mob,dept,desi,ldt,hr,charges);
			break;
		}
		
		return idao.save(emp);
	}
		
}

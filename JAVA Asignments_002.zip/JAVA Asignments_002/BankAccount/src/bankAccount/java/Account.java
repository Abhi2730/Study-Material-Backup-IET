package bankAccount.java;

public class Account {

	private int id;
	private String name;
	private double balance;
	
	
}6tr4ede	 

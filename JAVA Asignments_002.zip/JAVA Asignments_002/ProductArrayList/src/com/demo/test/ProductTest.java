package com.demo.test;
import java.util.*;

import com.demo.beans.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;
public class ProductTest {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ProductService pservice=new ProductServiceImpl(); 
		int ch = 0;
		
		do
		{
		System.out.println("1.Add new Product. \n2.Display All.\n3.Display By ID");
		System.out.println("4.Display By Name \n5.Display By Price \n6.Display in Sorted Order By Name"); 
		System.out.println("7.Display in Sorted Order By Price\n8.Display in Sorted Order By Qty \n9.Delete By Id \n10.Modify Product \n11. Exit");
		System.out.println("Enter Your Choice: ");
		ch=sc.nextInt();
		
		switch(ch)
		{
		case 1:
			boolean status = pservice.addNewProduct();
			if(status)
			{
				System.out.println("Added Success!");
			}
			else
			{
				System.out.println("Product Not Added!");
			}
			break;
			
		case 2: 
			List<Product> list=pservice.displayAll();
			list.stream().forEach(ob->System.out.println(ob));
			break;

		case 3:
			System.out.println("Enter Id to Display");
			int pid=sc.nextInt();
			Product p=pservice.displayById(pid);
			
			if(p!=null)
			{
				System.out.println(p);
			}
			else
			{
				System.out.println("Id Not Found");
			}
			break;

		case 4: 
			System.out.println("Enter Name to search: ");
			String name=sc.next();
			List<Product> plist=pservice.displayByName(name);
			
			plist.stream().forEach(ob->System.out.println(ob));
			break;
		
		case 5: 
			System.out.println("Enter Price to search: ");
			float price=sc.nextFloat();
			plist=pservice.displayByPrice(price);
			plist.stream().forEach(ob->System.out.println(ob));
			break;
		
		case 6: 
			plist=pservice.sortByName();
			plist.stream().forEach(System.out::println);
			break;
		
		case 7: 
			plist = pservice.sortByPrice();
			plist.stream().forEach(System.out :: println);
			break;
		
		case 8: 
			plist=pservice.sortByQty();
			plist.stream().forEach(ob->System.out.println(ob));
			break;
		
		case 9: 
			System.out.println("Enter Product Id to delete: ");
			int id=sc.nextInt();
			status=pservice.deleteById(id);
			if(status)
			{
				System.out.println("Deletion Succefull");
			}
			else
			{
				System.out.println("Deletion Failed!");
			}
			break;

		case 10: 
			System.out.println("Enter Item id to modify: ");
			id=sc.nextInt();
			System.out.println("Enter Item quantity to modify: ");
			int quant=sc.nextInt();
			System.out.println("Enter Item price to modify: ");
			price=sc.nextFloat();
			status=pservice.modifyProduct(id,quant,price);
			if(status)
			{
				System.out.println("Product modifies succesfully!");
				
			}
			else
			{
				System.out.println("Product modification failed!");
			}
			
			
			break;
		
		case 11: 
			sc.close();
			System.out.println("Thank you for visiting!");
			break;

		default: 
			System.out.println("Wrong Choice!");
			break;

		
		}
		}while(ch!=11);
		
		
		
	}
	
	

}

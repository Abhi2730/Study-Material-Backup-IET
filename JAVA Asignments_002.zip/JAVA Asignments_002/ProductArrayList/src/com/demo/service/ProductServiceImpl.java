package com.demo.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;
import com.demo.beans.Product;

public class ProductServiceImpl implements ProductService {
	
	private ProductDao pdao;

	public ProductServiceImpl() {
		
		super();
		pdao=new ProductDaoImpl();
		
	}

	@Override
	public boolean addNewProduct()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Product Id: ");
		int pid=sc.nextInt();
		System.out.println("Enter Product name: ");
		String pname=sc.next();
		System.out.println("Enter Product Qty: ");
		int pqty=sc.nextInt();
		System.out.println("Enter Product Price: ");
		float price=sc.nextFloat();
		System.out.println("Enter Product Expiry Date: (dd/MM/yyyy) ");
		String expdate=sc.next();
		LocalDate ldt = LocalDate.parse(expdate,DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		
		Product p = new Product(pid,pname,pqty,price,ldt);
		
		return pdao.save(p);
		
		
		
		
	}

	@Override
	public List<Product> displayAll() {
		
		return pdao.findAll();
	}

	@Override
	public Product displayById(int pid) {
		
		return pdao.findById(pid);
	}

	@Override
	public List<Product> displayByName(String name) {
		
		return pdao.findByName(name);
	}

	@Override
	public List<Product> displayByPrice(float price) {
		
		return pdao.findByPrice(price);
	}

	@Override
	public List<Product> sortByName() {
		
		return pdao.disSortByName();
	}

	@Override
	public List<Product> sortByQty() {
		
		return pdao.arrangeByQty();
	}

	@Override
	public List<Product> sortByPrice() {

		return pdao.arrangeByPrice();
	}

	@Override
	public boolean deleteById(int id) {
		
		return pdao.removeById(id);
	}

	@Override
	public boolean modifyProduct(int id, int quant, float price) {
		
		return pdao.modifyProduct(id,quant,price);
	}
	
	
	

}

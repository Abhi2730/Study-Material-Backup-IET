package Interfaces;

public interface CalculateBalance {
	
	public void calbal();

}

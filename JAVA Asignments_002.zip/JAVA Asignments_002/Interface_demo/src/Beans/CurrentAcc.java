package Beans;

import java.util.Date;

import Interfaces.CalculateBalance;

public class CurrentAcc extends Account implements CalculateBalance {
		private int roi;
		private float mbalance;
		
		
		
		public CurrentAcc()
		{
			
		}

		public CurrentAcc(String accno, String name, Date doa,int roi,float mbalance) {
			super(accno,name,doa);
			this.roi = roi;
			this.mbalance=mbalance;
		}
		
		
		public float getMbalance() {
			return mbalance;
		}

		public void setMbalance(float mbalance) {
			this.mbalance = mbalance;
		}
		
		public int getRoi() {
			return roi;
		}

		public void setRoi(int roi) {
			this.roi = roi;
		}

		@Override
		public String toString() {
			return super.toString()+"CurrentAcc [roi=" + roi + "]";
		}

		@Override
		public void calbal() {
			System.out.println("CalBal method of Current account");
			System.out.println("Calculated Balance is: "+roi*mbalance);
			
		}
		
		
		
		
		
		
		
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_on_Collection
{
    internal class Program
    {
        
            static void Main(string[] args)
            {
                Console.WriteLine("Enter No of Employees ");
                int empNO = Convert.ToInt32(Console.ReadLine());
                Employee[] emp = new Employee[empNO];
                Console.WriteLine("Enter the information of Employee");
                for (int i = 0; i < empNO; i++)
                {
                    Employee e = new Employee();
                    Console.Write("Enter Employee ID: ");
                    e.Id = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Employee Name: ");
                    e.Name = Console.ReadLine();
                    Console.Write("Enter Employee Address: ");
                    e.Address = Console.ReadLine();
                    Console.Write("Enter Employee Salary: ");
                    e._Salary = Convert.ToInt32(Console.ReadLine());
                    emp[i] = e;


                }
                Console.WriteLine("Enter Id to print Details"); //Search Employee by id 
                int EmployeeToBeSearch = Convert.ToInt32(Console.ReadLine());
                foreach (Employee e in emp) //e is obj  emp is arrayName
                {
                    if (e.Id == EmployeeToBeSearch)
                    {
                        Console.WriteLine(e.GetEmpDetails());
                    }

                }



                Console.ReadLine();
            }
        }
        public class Employee //set Getter Setter Properties
        {
            private int _EId;
            private string _EName;
            private string _EAddress;
            private int _ESalary;

            public int _Salary
            {
                get { return _ESalary; }
                set { _ESalary = value; }
            }


            public string Address
            {
                get { return _EAddress; }
                set { _EAddress = value; }
            }


            public string Name
            {
                get { return _EName; }
                set { _EName = value; }
            }


            public int Id
            {
                get { return _EId; }
                set { _EId = value; }
            }

            public string GetEmpDetails()
            {
                return string.Format("Id ={0}, Name ={1}, Address ={2} , Salary={3}", _EId, _EName, _EAddress, _Salary);
            }

        }
    }
    


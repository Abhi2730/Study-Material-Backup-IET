﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[10];
            int count = 0
            Console.WriteLine("Enter Id No");
            int pin = Convert.ToInt32(Console.ReadLine());
            if (pin >= 1000 && pin <= 9999)
            {

            }
            else
            {
                Console.WriteLine("Please Enter 4 digit ID ");
                return;
            }
            Console.WriteLine("Enter the Password");

            string pass = Console.ReadLine();
            string Setpass = "0";
            if (Setpass == pass)
            {
                Console.WriteLine(" \n Login Success");
            }
            else
            {
                Console.WriteLine("Please Enter Correct Password ");
                return;
            }

            int Bal = 2000;



            do
            {
                Console.WriteLine(" \n----------------------------\n 1.Get Balance \n 2.Withdraw \n 3.Deposite \n 4.View Passbook \n 5.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());


                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Get Balance");
                        Console.WriteLine("Your balance is : " + Bal);
                        break;
                    case 2:
                        Console.WriteLine("Withdraw");
                        Console.WriteLine("Enter Amount To withdraw");
                        with = Convert.ToInt32(Console.ReadLine());

                        

                        if (Bal >= with)
                        {
                            Bal = Bal - with;
                            Console.WriteLine("Withdraw Success of Rs " + with + "  Remeaning balance is " + Bal);
                            arr[count++] = "withdraw -" + with;
                        }
                        else
                        {
                            Console.WriteLine("Insufficient funds");
                            return;
                        }
                        break;
                    case 3:
                        Console.WriteLine("Deposite");
                        Console.WriteLine("Enter the Deposite Amount");
                        depo = Convert.ToInt32(Console.ReadLine());
                        Bal = Bal + depo;
                        Console.WriteLine("Deposited balance " + depo + "  total balance is :  " + Bal);
                        arr[count++] = "deposite +" + depo;
                        break;
                    case 4:
                        Console.WriteLine("View History");
                        Console.WriteLine("total balance is " + Bal);
                       for(int i = 0; i<=count; i++)
                        {
                            Console.WriteLine(arr[i]);
                        }

                        break;
                    case 5:
                        Console.WriteLine("-------------Thanks for Visiting Close the Window-------------");
                        return;

                }
            } while (true);

        }
    }
}
